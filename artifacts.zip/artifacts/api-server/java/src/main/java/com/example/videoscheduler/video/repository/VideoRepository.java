package com.example.videoscheduler.video.repository;

import com.example.videoscheduler.video.entity.Video;
import java.util.UUID;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VideoRepository extends JpaRepository<Video, UUID> {

    Page<Video> findByTitleContainingIgnoreCase(String title, Pageable pageable);
}