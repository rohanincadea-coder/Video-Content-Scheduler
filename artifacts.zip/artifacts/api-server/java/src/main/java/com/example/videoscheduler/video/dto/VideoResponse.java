package com.example.videoscheduler.video.dto;

import com.example.videoscheduler.video.entity.Video;
import java.time.Instant;
import java.util.UUID;

public record VideoResponse(
        UUID id,
        String title,
        String description,
        String videoUrl,
        String thumbnailUrl,
        Instant createdAt,
        Instant updatedAt
) {
    public static VideoResponse from(Video video) {
        return new VideoResponse(
                video.getId(),
                video.getTitle(),
                video.getDescription(),
                video.getVideoUrl(),
                video.getThumbnailUrl(),
                video.getCreatedAt(),
                video.getUpdatedAt()
        );
    }
}