package com.example.videoscheduler.common.error;

import java.util.UUID;

public class VideoNotFoundException extends RuntimeException {

    public VideoNotFoundException(UUID id) {
        super("Video was not found: " + id);
    }
}