package com.example.videoscheduler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VideoSchedulerApplication {

    public static void main(String[] args) {
        SpringApplication.run(VideoSchedulerApplication.class, args);
    }
}