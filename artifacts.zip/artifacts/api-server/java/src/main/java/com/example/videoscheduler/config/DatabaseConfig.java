package com.example.videoscheduler.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import javax.sql.DataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

@Configuration
public class DatabaseConfig {

    @Bean
    public DataSource dataSource(Environment environment) {
        String configuredUrl = firstNonBlank(
                environment.getProperty("JDBC_DATABASE_URL"),
                environment.getProperty("DATABASE_URL")
        );

        if (configuredUrl == null) {
            throw new IllegalStateException(
                    "DATABASE_URL or JDBC_DATABASE_URL must be configured before starting the application"
            );
        }

        HikariConfig hikariConfig = new HikariConfig();
        hikariConfig.setJdbcUrl(toJdbcUrl(configuredUrl));
        hikariConfig.setDriverClassName("org.postgresql.Driver");

        if (!configuredUrl.startsWith("jdbc:")) {
            URI databaseUri = URI.create(configuredUrl);
            if (databaseUri.getUserInfo() != null) {
                String[] credentials = databaseUri.getUserInfo().split(":", 2);
                hikariConfig.setUsername(decode(credentials[0]));
                if (credentials.length == 2) {
                    hikariConfig.setPassword(decode(credentials[1]));
                }
            }
        }

        hikariConfig.setMaximumPoolSize(10);
        hikariConfig.setMinimumIdle(2);
        hikariConfig.setPoolName("video-scheduler-pool");
        return new HikariDataSource(hikariConfig);
    }

    private static String toJdbcUrl(String configuredUrl) {
        if (configuredUrl.startsWith("jdbc:")) {
            return configuredUrl;
        }
        if (configuredUrl.startsWith("postgres://") || configuredUrl.startsWith("postgresql://")) {
            URI databaseUri = URI.create(configuredUrl);
            String authority = databaseUri.getRawAuthority();
            int credentialsSeparator = authority.lastIndexOf('@');
            if (credentialsSeparator >= 0) {
                authority = authority.substring(credentialsSeparator + 1);
            }
            String query = databaseUri.getRawQuery() == null
                    ? ""
                    : "?" + databaseUri.getRawQuery();
            return "jdbc:postgresql://" + authority + databaseUri.getRawPath() + query;
        }
        throw new IllegalArgumentException(
                "DATABASE_URL must use a PostgreSQL URL with postgres://, postgresql://, or jdbc:postgresql://"
        );
    }

    private static String firstNonBlank(String first, String second) {
        if (first != null && !first.isBlank()) {
            return first;
        }
        if (second != null && !second.isBlank()) {
            return second;
        }
        return null;
    }

    private static String decode(String value) {
        return URLDecoder.decode(value, StandardCharsets.UTF_8);
    }
}