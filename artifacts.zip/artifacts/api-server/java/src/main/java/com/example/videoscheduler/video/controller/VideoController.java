package com.example.videoscheduler.video.controller;

import com.example.videoscheduler.common.dto.PageResponse;
import com.example.videoscheduler.video.dto.CreateVideoRequest;
import com.example.videoscheduler.video.dto.UpdateVideoRequest;
import com.example.videoscheduler.video.dto.VideoResponse;
import com.example.videoscheduler.video.service.VideoService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import java.net.URI;
import java.util.UUID;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Validated
@RestController
@RequestMapping("/v1/videos")
public class VideoController {

    private final VideoService videoService;

    public VideoController(VideoService videoService) {
        this.videoService = videoService;
    }

    @PostMapping
    public ResponseEntity<VideoResponse> create(@Valid @RequestBody CreateVideoRequest request) {
        VideoResponse response = videoService.create(request);
        return ResponseEntity.created(URI.create("/api/v1/videos/" + response.id())).body(response);
    }

    @GetMapping
    public PageResponse<VideoResponse> list(
            @RequestParam(required = false) String title,
            @RequestParam(defaultValue = "0") @Min(0) int page,
            @RequestParam(defaultValue = "20") @Min(1) @Max(100) int size
    ) {
        return videoService.list(title, page, size);
    }

    @GetMapping("/{id}")
    public VideoResponse get(@PathVariable UUID id) {
        return videoService.get(id);
    }

    @PatchMapping("/{id}")
    public VideoResponse update(
            @PathVariable UUID id,
            @Valid @RequestBody UpdateVideoRequest request
    ) {
        return videoService.update(id, request);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable UUID id) {
        videoService.delete(id);
        return ResponseEntity.noContent().build();
    }
}