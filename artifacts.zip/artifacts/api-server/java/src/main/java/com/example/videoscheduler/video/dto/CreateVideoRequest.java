package com.example.videoscheduler.video.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public record CreateVideoRequest(
        @NotBlank(message = "title must not be blank")
        @Size(max = 200, message = "title must be 200 characters or fewer")
        String title,

        @Size(max = 2000, message = "description must be 2000 characters or fewer")
        String description,

        @NotBlank(message = "videoUrl must not be blank")
        @Size(max = 2048, message = "videoUrl must be 2048 characters or fewer")
        @Pattern(regexp = "https?://.+", message = "videoUrl must be a valid HTTP or HTTPS URL")
        String videoUrl,

        @Size(max = 2048, message = "thumbnailUrl must be 2048 characters or fewer")
        @Pattern(regexp = "https?://.+", message = "thumbnailUrl must be a valid HTTP or HTTPS URL")
        String thumbnailUrl
) {
}