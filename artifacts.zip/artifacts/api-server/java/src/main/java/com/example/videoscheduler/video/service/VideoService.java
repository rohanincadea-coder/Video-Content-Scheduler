package com.example.videoscheduler.video.service;

import com.example.videoscheduler.common.dto.PageResponse;
import com.example.videoscheduler.common.error.VideoNotFoundException;
import com.example.videoscheduler.video.dto.CreateVideoRequest;
import com.example.videoscheduler.video.dto.UpdateVideoRequest;
import com.example.videoscheduler.video.dto.VideoResponse;
import com.example.videoscheduler.video.entity.Video;
import com.example.videoscheduler.video.repository.VideoRepository;
import java.util.UUID;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class VideoService {

    private final VideoRepository videoRepository;

    public VideoService(VideoRepository videoRepository) {
        this.videoRepository = videoRepository;
    }

    @Transactional
    public VideoResponse create(CreateVideoRequest request) {
        Video video = new Video(
                request.title().trim(),
                request.description(),
                request.videoUrl(),
                request.thumbnailUrl()
        );
        return VideoResponse.from(videoRepository.save(video));
    }

    @Transactional(readOnly = true)
    public PageResponse<VideoResponse> list(String title, int page, int size) {
        PageRequest pageRequest = PageRequest.of(
                page,
                size,
                Sort.by(Sort.Direction.DESC, "createdAt")
        );
        Page<Video> videos = title == null || title.isBlank()
                ? videoRepository.findAll(pageRequest)
                : videoRepository.findByTitleContainingIgnoreCase(title.trim(), pageRequest);
        return new PageResponse<>(
                videos.map(VideoResponse::from).getContent(),
                videos.getNumber(),
                videos.getSize(),
                videos.getTotalElements(),
                videos.getTotalPages(),
                videos.isFirst(),
                videos.isLast()
        );
    }

    @Transactional(readOnly = true)
    public VideoResponse get(UUID id) {
        return VideoResponse.from(findVideo(id));
    }

    @Transactional
    public VideoResponse update(UUID id, UpdateVideoRequest request) {
        Video video = findVideo(id);
        video.update(request.title(), request.description(), request.videoUrl(), request.thumbnailUrl());
        return VideoResponse.from(video);
    }

    @Transactional
    public void delete(UUID id) {
        Video video = findVideo(id);
        videoRepository.delete(video);
    }

    private Video findVideo(UUID id) {
        return videoRepository.findById(id).orElseThrow(() -> new VideoNotFoundException(id));
    }
}