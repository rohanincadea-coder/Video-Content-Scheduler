package com.example.videoscheduler.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI videoSchedulerOpenApi() {
        return new OpenAPI()
                .info(new Info()
                        .title("Video Content Scheduler API")
                        .version("v1")
                        .description("Backend API for managing video content. Scheduling and publishing are introduced in later milestones."));
    }
}