CREATE TABLE videos (
    id UUID PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description VARCHAR(2000),
    video_url VARCHAR(2048) NOT NULL,
    thumbnail_url VARCHAR(2048),
    created_by UUID,
    created_at TIMESTAMPTZ NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL
);

CREATE INDEX idx_videos_created_at ON videos (created_at DESC);
CREATE INDEX idx_videos_title_lower ON videos (LOWER(title));